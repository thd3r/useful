package repository

import (
	"github.com/thd3r/employee/internal/database"
	"github.com/thd3r/employee/internal/domain"
)

type ServiceAppRepository struct {
	EmployeeRepository
	db database.Service
}

func NewApp(db database.Service) domain.AppRepository {
	return &ServiceAppRepository{
		EmployeeRepository: EmployeeRepository{
			db: db,
		},
		db: db,
	}
}

// Index implements domain.AppRepository.
func (s *ServiceAppRepository) Index() string {
	return "OK"
}

// Health implements domain.AppRepository.
func (s *ServiceAppRepository) Health() map[string]string {
	return s.db.Health()
}
