package repository

import (
	"github.com/thd3r/employee/internal/database"
	"github.com/thd3r/employee/internal/domain"
)

type EmployeeRepository struct {
	db database.Service
}

func NewEmployee(db database.Service) domain.EmployeeRepository {
	return &EmployeeRepository{
		db: db,
	}
}

// Create implements domain.EmployeeRepository.
func (e *EmployeeRepository) Create(employee *domain.Employee) error {
	return e.db.Conn().Create(&employee).Error
}

// Update implements domain.EmployeeRepository.
func (e *EmployeeRepository) Update(employee *domain.Employee, id string) error {
	return e.db.Conn().Where("id = ?", id).Updates(&employee).Error
}

// Delete implements domain.EmployeeRepository.
func (e *EmployeeRepository) Delete(employee *domain.Employee, id string) error {
	return e.db.Conn().Where("id = ?", id).Delete(&employee).Error
}

// GetAll implements domain.EmployeeRepository.
func (e *EmployeeRepository) GetAll(employee *[]domain.Employee) error {
	return e.db.Conn().Find(&employee).Error
}

// GetById implements domain.EmployeeRepository.
func (e *EmployeeRepository) GetById(employee *domain.Employee, id string) error {
	return e.db.Conn().First(&employee, "id = ?", id).Error
}
