package database

import "gorm.io/gorm"

// Service represents a service that interacts with a database.
type Service interface {
	Conn() *gorm.DB
	// Health returns a map of health status information.
	// The keys and values in the map are service-specific.
	Health() map[string]string

	// Close terminates the database connection.
	// It returns an error if the connection cannot be closed.
	Close() error
}
