package usecase

import (
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/thd3r/employee/internal/domain"
	"github.com/thd3r/employee/internal/dto"
	"gorm.io/gorm"
)

type EmployeeUsecase struct {
	employeeRepo domain.EmployeeRepository
}

func NewEmployee(repo domain.EmployeeRepository) domain.EmployeeUsecase {
	return &EmployeeUsecase{
		employeeRepo: repo,
	}
}

// CreateEmployee implements domain.EmployeeUsecase.
func (e *EmployeeUsecase) CreateEmployee(requestCreate *dto.CreateEmployeeRequest) (*domain.Employee, error) {
	newEmployee := &domain.Employee{
		Id:        uuid.New().String(),
		Nickname:  requestCreate.Nickname,
		Fullname:  requestCreate.Fullname,
		Email:     requestCreate.Email,
		Phone:     requestCreate.Phone,
		Address:   requestCreate.Address,
		CreatedAt: time.Now(),
	}
	return newEmployee, e.employeeRepo.Create(newEmployee)
}

// UpdateEmployee implements domain.EmployeeUsecase.
func (e *EmployeeUsecase) UpdateEmployee(requestUpdate *dto.UpdateEmployeeRequest, id string) (*domain.Employee, error) {
	dataEmployee := new(domain.Employee)

	if err := e.employeeRepo.GetById(dataEmployee, id); err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, fmt.Errorf("Employee with name %s not found", requestUpdate.Fullname)
		}
		return nil, err
	}

	if requestUpdate.Nickname != "" {
		dataEmployee.Nickname = requestUpdate.Nickname
	}

	if requestUpdate.Fullname != "" {
		dataEmployee.Fullname = requestUpdate.Fullname
	}

	if requestUpdate.Email != "" {
		dataEmployee.Email = requestUpdate.Email
	}

	if requestUpdate.Phone != "" {
		dataEmployee.Phone = requestUpdate.Phone
	}

	if requestUpdate.Address != "" {
		dataEmployee.Address = requestUpdate.Address
	}

	dataEmployee.UpdatedAt = time.Now()

	return dataEmployee, e.employeeRepo.Update(dataEmployee, id)

}

// DeleteEmployee implements domain.EmployeeUsecase.
func (e *EmployeeUsecase) DeleteEmployee(employee *domain.Employee, id string) error {
	dataEmployee := new(domain.Employee)

	return e.employeeRepo.Delete(dataEmployee, id)
}

// GetAllEmployee implements domain.EmployeeUsecase.
func (e *EmployeeUsecase) GetAllEmployee() (*[]domain.Employee, error) {
	var dataEmployee []domain.Employee

	if err := e.employeeRepo.GetAll(&dataEmployee); err != nil {
		return nil, err
	}

	return &dataEmployee, nil
}

// GetByIdEmployee implements domain.EmployeeUsecase.
func (e *EmployeeUsecase) GetByIdEmployee(employee *domain.Employee, id string) (*domain.Employee, error) {
	dataEmployee := new(domain.Employee)

	return dataEmployee, e.employeeRepo.GetById(dataEmployee, id)
}
