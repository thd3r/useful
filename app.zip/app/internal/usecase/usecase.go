package usecase

import "github.com/thd3r/employee/internal/domain"

type ServiceAppUsecase struct {
	EmployeeUsecase
	appRepo domain.AppRepository
}

func NewApp(appRepo domain.AppRepository) domain.AppUsecase {
	employeeRepo := new(domain.EmployeeRepository)

	return &ServiceAppUsecase{
		EmployeeUsecase: EmployeeUsecase{
			employeeRepo: *employeeRepo,
		},
		appRepo: appRepo,
	}
}

// Index implements domain.AppUsecase.
func (s *ServiceAppUsecase) Index() string {
	return s.appRepo.Index()
}

// Health implements domain.AppUsecase.
func (s *ServiceAppUsecase) Health() map[string]string {
	return s.appRepo.Health()
}