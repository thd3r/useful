package route

import (
	"github.com/gofiber/fiber/v2"
	"github.com/thd3r/employee/internal/controller"
	"github.com/thd3r/employee/internal/database"
)

func Setup(app *fiber.App, db database.Service) {
	handler := controller.NewAppController(db)

	app.Get("/", handler.Index)
	app.Get("/health", handler.Health)

	api := app.Group("/api")
	v1 := api.Group("/v1")

	employee := v1.Group("/employee")
	employee.Get("/", handler.EmployeeController.HandleGetAllEmployee)
	employee.Get("/:id", handler.EmployeeController.HandleGetByIdEmployee)
	employee.Post("/", handler.EmployeeController.HandleCreateEmployee)
	employee.Put("/:id", handler.EmployeeController.HandleUpdateEmployee)
	employee.Delete(":id", handler.EmployeeController.HandleDeleteEmployee)
}