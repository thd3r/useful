package route

import (
	"fmt"
	"os"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/thd3r/employee/internal/controller"

	_ "github.com/joho/godotenv/autoload"
)

var port, _ = strconv.Atoi(os.Getenv("PORT"))

func NewEmployeeRoute(v1 fiber.Router, handler *controller.EmployeeController) {
	route := v1.Group("/employee")
	route.Use(func(c *fiber.Ctx) error {
		c.Request().Header.Set("Origin", fmt.Sprintf("http://localhost:%d", port))
		return c.Next()
	})

	route.Use(cors.New(cors.Config{
		AllowOrigins: fmt.Sprintf("http://localhost:%d", port),
		AllowMethods: "GET, POST, PATCH, DELETE",
		AllowHeaders: "Content-Type, Origin, Accept",
		AllowCredentials: true,
	}))

	route.Get("/", handler.HandleGetAllEmployee)
	route.Get("/:id", handler.HandleGetByIdEmployee)
	route.Post("/", handler.HandleCreateEmployee)
	route.Put("/:id", handler.HandleUpdateEmployee)
	route.Delete(":id", handler.HandleDeleteEmployee)
}