package controller

import (
	"github.com/gofiber/fiber/v2"
	"github.com/thd3r/employee/internal/database"
	"github.com/thd3r/employee/internal/domain"
	"github.com/thd3r/employee/internal/repository"
	"github.com/thd3r/employee/internal/usecase"
)

type AppController struct {
	EmployeeController
	appUsecase domain.AppUsecase
}

func NewAppController(db database.Service) *AppController {
	appRepository := repository.NewApp(db)
	appUsecase := usecase.NewApp(appRepository)

	employeeRepository := repository.NewEmployee(db)
	employeeUsecase := usecase.NewEmployee(employeeRepository)
	
	employeeController := NewEmployee(employeeUsecase)

	return &AppController{
		EmployeeController: *employeeController,
		appUsecase: appUsecase,
	}
}

func (controller *AppController) Index(c *fiber.Ctx) error {
	return c.SendString(controller.appUsecase.Index())
}

func (controller *AppController) Health(c *fiber.Ctx) error {
	return c.JSON(controller.appUsecase.Health())
}
