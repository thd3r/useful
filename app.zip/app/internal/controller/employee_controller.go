package controller

import (
	"fmt"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/thd3r/employee/internal/domain"
	"github.com/thd3r/employee/internal/dto"
	"github.com/thd3r/employee/utils/validation"
	"gorm.io/gorm"
)

type EmployeeController struct {
	employeeUsecase domain.EmployeeUsecase
}

func NewEmployee(usecase domain.EmployeeUsecase) *EmployeeController {
	return &EmployeeController{
		employeeUsecase: usecase,
	}
}

func (controller *EmployeeController) HandleCreateEmployee(c *fiber.Ctx) error {
	requestCreate := new(dto.CreateEmployeeRequest)

	if err := c.BodyParser(&requestCreate); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": err.Error(),
			"code":  fiber.StatusBadRequest,
		})
	}

	if err := validation.ValidateRequestStruct(requestCreate); err != nil {
		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"errors": err,
			"code":   fiber.StatusOK,
		})
	}

	newEmployee, err := controller.employeeUsecase.CreateEmployee(requestCreate)
	if err != nil {
		if strings.Contains(err.Error(), "Duplicate entry") {
			return c.Status(fiber.StatusOK).JSON(fiber.Map{
				"error": fmt.Sprintf("Employee named %s is available", requestCreate.Fullname),
				"code":  fiber.StatusOK,
			})
		} else {
			return c.Status(fiber.StatusOK).JSON(fiber.Map{
				"error": fmt.Sprintf("Unable to update employees for %s", requestCreate.Fullname),
				"code":  fiber.StatusOK,
			})
		}
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"data": newEmployee,
		"code": fiber.StatusCreated,
	})
}

func (controller *EmployeeController) HandleUpdateEmployee(c *fiber.Ctx) error {
	employeeId := c.Params("id")
	requestUpdate := new(dto.UpdateEmployeeRequest)

	if err := c.BodyParser(&requestUpdate); err != nil {
		if err == gorm.ErrRecordNotFound {
			return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
				"error": fmt.Sprintf("Employee with name %s not found", requestUpdate.Fullname),
				"code":  fiber.StatusNotFound,
			})
		}

		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"errors": err.Error(),
			"code":   fiber.StatusBadRequest,
		})
	}

	if err := validation.ValidateRequestStruct(requestUpdate); err != nil {
		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"errors": err,
			"code":   fiber.StatusOK,
		})
	}

	employee := new(domain.Employee)

	_, err := controller.employeeUsecase.GetByIdEmployee(employee, employeeId)
	if err != nil {
		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"error": err.Error(),
			"code":  fiber.StatusOK,
		})
	}

	dataEmployee, err := controller.employeeUsecase.UpdateEmployee(requestUpdate, employeeId)
	if err != nil {
		if strings.Contains(err.Error(), "Duplicate entry") {
			return c.Status(fiber.StatusOK).JSON(fiber.Map{
				"error": fmt.Sprintf("Employee named %s is available", requestUpdate.Fullname),
				"code":  fiber.StatusOK,
			})
		} else {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error": fmt.Sprintf("Unable to update employees for %s", requestUpdate.Fullname),
				"code":  fiber.StatusBadRequest,
			})
		}
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"data": dataEmployee,
		"code": fiber.StatusOK,
	})

}

func (controller *EmployeeController) HandleDeleteEmployee(c *fiber.Ctx) error {
	employeeId := c.Params("id")
	dataEmployee := new(domain.Employee)

	if err := controller.employeeUsecase.DeleteEmployee(dataEmployee, employeeId); err != nil {
		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"error": err.Error(),
			"code":  fiber.StatusOK,
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"code": fiber.StatusOK,
	})
}

func (controller *EmployeeController) HandleGetByIdEmployee(c *fiber.Ctx) error {
	employeeId := c.Params("id")
	employee := new(domain.Employee)

	dataEmployee, err := controller.employeeUsecase.GetByIdEmployee(employee, employeeId)
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
				"error": fmt.Sprintf("Employee with id %v not found", employeeId),
				"code":  fiber.StatusNotFound,
			})
		}

		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"error": err.Error(),
			"code":  fiber.StatusOK,
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"data": dataEmployee,
		"code": fiber.StatusOK,
	})
}

func (controller *EmployeeController) HandleGetAllEmployee(c *fiber.Ctx) error {

	dataEmployee, err := controller.employeeUsecase.GetAllEmployee()
	if err != nil {
		c.Status(fiber.StatusOK).JSON(fiber.Map{
			"error": err.Error(),
			"code":  fiber.StatusOK,
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"data": dataEmployee,
		"code": fiber.StatusOK,
	})
}
