package server

type Service interface {
	Start(port int)
}