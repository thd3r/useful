package server

import (
	"fmt"

	"github.com/gofiber/fiber/v2"
	"github.com/thd3r/employee/internal/database"
	"github.com/thd3r/employee/internal/route"
)

type service struct {
	*fiber.App
	db database.Service
}

func NewFiberServer() Service {
	return &service{
		App: fiber.New(fiber.Config{
			AppName:      "Employee Management",
			ServerHeader: "localhost",
		}),
		db: database.New(),
	}
}

// Start implements Service.
func (s *service) Start(port int) {
	route.Setup(s.App, s.db)

	s.App.Listen(fmt.Sprintf(":%d", port))
}
