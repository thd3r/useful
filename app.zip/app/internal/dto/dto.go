package dto // Data Transfer Objects

type CreateEmployeeRequest struct {
	Nickname string `json:"nickname" validate:"required,min=3,max=20"`
	Fullname string `json:"fullname" validate:"required,min=3,max=50"`
	Email    string `json:"email" validate:"required,email"`
	Phone    string `json:"phone" validate:"required,min=8"`
	Address  string `json:"address"`
}

type UpdateEmployeeRequest struct {
	Nickname string `json:"nickname" validate:"max=20"`
	Fullname string `json:"fullname" validate:"max=50"`
	Email    string `json:"email"`
	Phone    string `json:"phone" validate:"max=20"`
	Address  string `json:"address"`
}
