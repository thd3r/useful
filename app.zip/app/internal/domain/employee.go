package domain

import (
	"time"

	"github.com/thd3r/employee/internal/dto"
)

type Employee struct {
	Id        string    `gorm:"type:char(36);primaryKey" json:"id"`
	Nickname  string    `gorm:"type:varchar(150)" json:"nickname"`
	Fullname  string    `gorm:"type:varchar(250)" json:"fullname"`
	Email     string    `gorm:"type:text" json:"email"`
	Phone     string    `gorm:"type:text" json:"phone"`
	Address   string    `gorm:"type:text" json:"address"`
	CreatedAt time.Time `gorm:"type:datetime" json:"created_at"`
	UpdatedAt time.Time `gorm:"type:datetime" json:"updated_at"`
}

type AppRepository interface {
	Index() string
	Health() map[string]string
}

type AppUsecase interface {
	Index() string
	Health() map[string]string
}

type EmployeeRepository interface {
	Create(employee *Employee) error
	Update(employee *Employee, id string) error
	Delete(employee *Employee, id string) error

	GetAll(employee *[]Employee) error
	GetById(employee *Employee, id string) error
}

type EmployeeUsecase interface {
	CreateEmployee(requestCreate *dto.CreateEmployeeRequest) (*Employee, error)
	UpdateEmployee(requestUpdate *dto.UpdateEmployeeRequest, id string) (*Employee, error)
	DeleteEmployee(employee *Employee, id string) error

	GetAllEmployee() (*[]Employee, error)
	GetByIdEmployee(employee *Employee, id string) (*Employee, error)
}
