package main

import (
	"os"
	"strconv"

	"github.com/thd3r/employee/internal/server"
	_ "github.com/joho/godotenv/autoload"
)

func main() {
	var port, _ = strconv.Atoi(os.Getenv("PORT"))

	server := server.NewFiberServer()
	server.Start(port)
}